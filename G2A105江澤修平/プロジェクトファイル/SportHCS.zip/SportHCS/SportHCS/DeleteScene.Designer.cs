﻿
namespace SportHCS
{
    partial class DeleteScene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TableDeleteButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.InputDeleteButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.home_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TableDeleteButton
            // 
            this.TableDeleteButton.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.TableDeleteButton.ForeColor = System.Drawing.Color.Blue;
            this.TableDeleteButton.Location = new System.Drawing.Point(462, 182);
            this.TableDeleteButton.Name = "TableDeleteButton";
            this.TableDeleteButton.Size = new System.Drawing.Size(232, 158);
            this.TableDeleteButton.TabIndex = 0;
            this.TableDeleteButton.Text = "テーブル削除";
            this.TableDeleteButton.UseVisualStyleBackColor = true;
            this.TableDeleteButton.Click += new System.EventHandler(this.TableDeleteButtonClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label1.Location = new System.Drawing.Point(317, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "削除画面";
            // 
            // InputDeleteButton
            // 
            this.InputDeleteButton.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.InputDeleteButton.ForeColor = System.Drawing.Color.Blue;
            this.InputDeleteButton.Location = new System.Drawing.Point(95, 182);
            this.InputDeleteButton.Name = "InputDeleteButton";
            this.InputDeleteButton.Size = new System.Drawing.Size(232, 158);
            this.InputDeleteButton.TabIndex = 2;
            this.InputDeleteButton.Text = "入力削除";
            this.InputDeleteButton.UseVisualStyleBackColor = true;
            this.InputDeleteButton.Click += new System.EventHandler(this.InputDeleteButtonClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label2.Location = new System.Drawing.Point(427, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(310, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "～ワンクリックで削除できるよ～";
            // 
            // home_button
            // 
            this.home_button.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.home_button.ForeColor = System.Drawing.Color.Blue;
            this.home_button.Location = new System.Drawing.Point(638, 12);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(150, 70);
            this.home_button.TabIndex = 4;
            this.home_button.Text = "メニューへ";
            this.home_button.UseVisualStyleBackColor = true;
            this.home_button.Click += new System.EventHandler(this.HomeButtonClick);
            // 
            // DeleteScene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.home_button);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.InputDeleteButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TableDeleteButton);
            this.Name = "DeleteScene";
            this.Text = "Delete_Scene";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button TableDeleteButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button InputDeleteButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button home_button;
    }
}