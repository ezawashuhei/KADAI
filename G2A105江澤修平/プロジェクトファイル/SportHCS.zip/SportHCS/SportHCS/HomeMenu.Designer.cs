﻿
namespace SportHCS
{
    partial class HomeMenu
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.SingupButton = new System.Windows.Forms.Button();
            this.ChangeButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.DateMakeingButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SingupButton
            // 
            this.SingupButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SingupButton.BackColor = System.Drawing.Color.White;
            this.SingupButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SingupButton.Font = new System.Drawing.Font("MS UI Gothic", 10F);
            this.SingupButton.ForeColor = System.Drawing.Color.Blue;
            this.SingupButton.Location = new System.Drawing.Point(160, 178);
            this.SingupButton.Name = "SingupButton";
            this.SingupButton.Size = new System.Drawing.Size(152, 89);
            this.SingupButton.TabIndex = 0;
            this.SingupButton.Text = "新規登録";
            this.SingupButton.UseVisualStyleBackColor = false;
            this.SingupButton.Click += new System.EventHandler(this.SingupButtonClick);
            // 
            // ChangeButton
            // 
            this.ChangeButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ChangeButton.BackColor = System.Drawing.Color.White;
            this.ChangeButton.Font = new System.Drawing.Font("MS UI Gothic", 10F);
            this.ChangeButton.ForeColor = System.Drawing.Color.Blue;
            this.ChangeButton.Location = new System.Drawing.Point(160, 305);
            this.ChangeButton.Name = "ChangeButton";
            this.ChangeButton.Size = new System.Drawing.Size(152, 89);
            this.ChangeButton.TabIndex = 1;
            this.ChangeButton.Text = "会員変更";
            this.ChangeButton.UseVisualStyleBackColor = false;
            this.ChangeButton.Click += new System.EventHandler(this.ChangeButtonClick);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteButton.BackColor = System.Drawing.Color.White;
            this.DeleteButton.Font = new System.Drawing.Font("MS UI Gothic", 10F);
            this.DeleteButton.ForeColor = System.Drawing.Color.Blue;
            this.DeleteButton.Location = new System.Drawing.Point(420, 178);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(151, 89);
            this.DeleteButton.TabIndex = 2;
            this.DeleteButton.Text = "会員削除";
            this.DeleteButton.UseVisualStyleBackColor = false;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButtonClick);
            // 
            // SearchButton
            // 
            this.SearchButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SearchButton.BackColor = System.Drawing.Color.White;
            this.SearchButton.Font = new System.Drawing.Font("MS UI Gothic", 10F);
            this.SearchButton.ForeColor = System.Drawing.Color.Blue;
            this.SearchButton.Location = new System.Drawing.Point(420, 305);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(151, 89);
            this.SearchButton.TabIndex = 3;
            this.SearchButton.Text = "会員検索";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButtonClick);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 40F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(122, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(650, 80);
            this.label1.TabIndex = 4;
            this.label1.Text = "HCSスポーツクラブ会員登録";
            // 
            // DateMakeingButton
            // 
            this.DateMakeingButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DateMakeingButton.Font = new System.Drawing.Font("MS UI Gothic", 10F);
            this.DateMakeingButton.ForeColor = System.Drawing.Color.Blue;
            this.DateMakeingButton.Location = new System.Drawing.Point(25, 45);
            this.DateMakeingButton.Name = "DateMakeingButton";
            this.DateMakeingButton.Size = new System.Drawing.Size(91, 80);
            this.DateMakeingButton.TabIndex = 5;
            this.DateMakeingButton.Text = "DB作成";
            this.DateMakeingButton.UseVisualStyleBackColor = true;
            this.DateMakeingButton.Click += new System.EventHandler(this.DateMakeingButtonClick);
            // 
            // HomeMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(754, 438);
            this.Controls.Add(this.DateMakeingButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.ChangeButton);
            this.Controls.Add(this.SingupButton);
            this.Font = new System.Drawing.Font("MS UI Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "HomeMenu";
            this.Text = "HCSスポーツクラブ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button SingupButton;
        private System.Windows.Forms.Button ChangeButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DateMakeingButton;
    }
}

