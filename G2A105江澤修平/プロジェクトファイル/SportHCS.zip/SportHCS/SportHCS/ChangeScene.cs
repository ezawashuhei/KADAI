﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
namespace SportHCS
{
    //データ変更フォーム
    public partial class ChangeScene : Form
    {
        public ChangeScene()
        {
            InitializeComponent();
        }
        /// <summary>
        /// データベースの中身の変更
        /// </summary>
        private void VerificationButtonClick(object sender, EventArgs e)//データベースの中身の変更
        {
            using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))
            {
                // DataTableを生成します。
                var dataTable = new DataTable();
                // SQLの実行
                var adapter = new SQLiteDataAdapter("SELECT * FROM t_product", con);
                adapter.Fill(dataTable);
                DataGridView.DataSource = dataTable;
            }
        }

        /// <summary>
        /// テキストボックス内に中身が入ってなければ
        /// エラーメッセージを表示する。
        /// 正しく記入されていれば内容を変更する
        /// </summary>
        private void ChangeButtonClick(object sender, EventArgs e)//変更ボタン
        {
            //もしテキストに何も書いてなかったら
            if (NameBox.Text == "" || CallNumberBox.Text == "" || SchoolIDBox.Text == "" || IDBox.Text == null || IDBox.Text == "ID")
            {
                MessageBox.Show("正しい値を入力してください。", "エラー",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
            else
            {
                using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))
                {
                    con.Open();
                    using (SQLiteTransaction trans = con.BeginTransaction())
                    {
                        SQLiteCommand cmd = con.CreateCommand();
                        // インサート
                        //コマンド　テーブル名　セット（挿入）　行名＝＠引数,　行名２＝＠引数２,　行名３＝＠引数３　WHERE  
                        cmd.CommandText = "UPDATE  t_product set name = @Name, callNumber =@CallNumber, schoolID = @SchoolID WHERE ID= @Id";
                        // パラメータセット
                        cmd.Parameters.Add("Name", System.Data.DbType.String);
                        cmd.Parameters.Add("CallNumber", System.Data.DbType.String);
                        cmd.Parameters.Add("SchoolID", System.Data.DbType.String);
                        cmd.Parameters.Add("Id", System.Data.DbType.Int64);
                        //データ修正
                        cmd.Parameters["Name"].Value = NameBox.Text;
                        cmd.Parameters["CallNumber"].Value = CallNumberBox.Text;
                        cmd.Parameters["SchoolID"].Value = SchoolIDBox.Text;
                        cmd.Parameters["Id"].Value = int.Parse(IDBox.Text);
                        cmd.ExecuteNonQuery();

                        // コミット
                        trans.Commit();
                    }
                }
            }
        }

        /// <summary>
        /// ホーム画面に戻る。
        /// </summary>
        private void HomeButtonClick(object sender, EventArgs e)//メニューへ戻る
        {
            //次画面を非表示
            this.Visible = false;

            HomeMenu home = new HomeMenu();
            home.Show();
        }

        /// <summary>
        /// 英数字のみしか記入できないように設定。
        /// </summary>
        private void NumberBoxKeyPress(object sender, KeyPressEventArgs Number)//英数字のみ記入可能
        {
            //バックスペースが推されたときは有効
            if (Number.KeyChar == '\b')
            {
                return;
            }

            //数値0～9以外を押されたときはイベントキャンセル
            if (Number.KeyChar < '0' || '9' < Number.KeyChar)
            {
                Number.Handled = true;
            }
        }
    }
}
