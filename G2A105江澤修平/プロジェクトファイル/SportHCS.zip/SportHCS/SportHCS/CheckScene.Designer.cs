﻿
namespace SportHCS
{
    partial class Check
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CheckButton = new System.Windows.Forms.Button();
            this.DataGridView = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.CompletionButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CheckButton
            // 
            this.CheckButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CheckButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.CheckButton.ForeColor = System.Drawing.Color.Blue;
            this.CheckButton.Location = new System.Drawing.Point(173, 361);
            this.CheckButton.Name = "CheckButton";
            this.CheckButton.Size = new System.Drawing.Size(138, 62);
            this.CheckButton.TabIndex = 0;
            this.CheckButton.Text = "確認";
            this.CheckButton.UseVisualStyleBackColor = true;
            this.CheckButton.Click += new System.EventHandler(this.VerificationButtonClick);
            // 
            // DataGridView
            // 
            this.DataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView.Location = new System.Drawing.Point(103, 104);
            this.DataGridView.Name = "DataGridView";
            this.DataGridView.RowHeadersWidth = 51;
            this.DataGridView.RowTemplate.Height = 24;
            this.DataGridView.Size = new System.Drawing.Size(598, 251);
            this.DataGridView.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(315, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 34);
            this.label3.TabIndex = 6;
            this.label3.Text = "確認画面";
            // 
            // CompletionButton
            // 
            this.CompletionButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CompletionButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.CompletionButton.ForeColor = System.Drawing.Color.Blue;
            this.CompletionButton.Location = new System.Drawing.Point(512, 361);
            this.CompletionButton.Name = "CompletionButton";
            this.CompletionButton.Size = new System.Drawing.Size(138, 62);
            this.CompletionButton.TabIndex = 7;
            this.CompletionButton.Text = "完了";
            this.CompletionButton.UseVisualStyleBackColor = true;
            this.CompletionButton.Click += new System.EventHandler(this.CompletionButtonClick);
            // 
            // Check
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(817, 450);
            this.Controls.Add(this.CompletionButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DataGridView);
            this.Controls.Add(this.CheckButton);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.Name = "Check";
            this.Text = "Check_Scene";
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CheckButton;
        private System.Windows.Forms.DataGridView DataGridView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CompletionButton;
    }
}