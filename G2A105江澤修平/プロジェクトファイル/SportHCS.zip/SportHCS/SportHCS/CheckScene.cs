﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;

namespace SportHCS
{
    //データ確認するだけのフォーム
    public partial class Check : Form
    {
        public Check()
        {
            InitializeComponent();
        }

        /// <summary>
        /// （前のフォームにて登録されたデータを）
        /// ビューを起動し、t_productの中身を表示する。
        /// </summary>
        private void VerificationButtonClick(object sender, EventArgs e)//確認
        {
            using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))
            {
                // DataTableを生成します
                var dataTable = new DataTable();
                // SQLの実行
                var adapter = new SQLiteDataAdapter("SELECT * FROM t_product", con);
                adapter.Fill(dataTable);
                DataGridView.DataSource = dataTable;
            }
        }

        /// <summary>
        /// ホーム画面へ戻る。
        /// </summary>
        private void CompletionButtonClick(object sender, EventArgs e)//完了
        {

            this.Visible = false;
            //ホーム画面へ
            HomeMenu home = new HomeMenu();
            home.Show();
        }
    }
}
