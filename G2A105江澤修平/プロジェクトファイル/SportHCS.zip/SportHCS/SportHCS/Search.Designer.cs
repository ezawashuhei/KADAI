﻿
namespace SportHCS
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.NumberBox = new System.Windows.Forms.TextBox();
            this.HcsSportView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.IDButton = new System.Windows.Forms.RadioButton();
            this.SchoolIDButton = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.HcsSportView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 30F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(275, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 50);
            this.label3.TabIndex = 8;
            this.label3.Text = "検索画面";
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.SearchButton.ForeColor = System.Drawing.Color.Blue;
            this.SearchButton.Location = new System.Drawing.Point(675, 157);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(113, 48);
            this.SearchButton.TabIndex = 9;
            this.SearchButton.Text = "検索";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButtonClick);
            // 
            // NumberBox
            // 
            this.NumberBox.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.NumberBox.Location = new System.Drawing.Point(377, 164);
            this.NumberBox.Name = "NumberBox";
            this.NumberBox.Size = new System.Drawing.Size(292, 41);
            this.NumberBox.TabIndex = 10;
            this.NumberBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberBoxKeyPress);
            // 
            // HcsSportView
            // 
            this.HcsSportView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HcsSportView.Location = new System.Drawing.Point(77, 222);
            this.HcsSportView.Name = "HcsSportView";
            this.HcsSportView.RowHeadersWidth = 51;
            this.HcsSportView.RowTemplate.Height = 24;
            this.HcsSportView.Size = new System.Drawing.Size(623, 193);
            this.HcsSportView.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label1.Location = new System.Drawing.Point(53, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(628, 34);
            this.label1.TabIndex = 12;
            this.label1.Text = "検索するIDまたは学籍番号を入力してください";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.BackButton.ForeColor = System.Drawing.Color.Blue;
            this.BackButton.Location = new System.Drawing.Point(25, 12);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(101, 60);
            this.BackButton.TabIndex = 17;
            this.BackButton.Text = "戻る";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButtonClick);
            // 
            // IDButton
            // 
            this.IDButton.AutoSize = true;
            this.IDButton.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.IDButton.Location = new System.Drawing.Point(15, 15);
            this.IDButton.Name = "IDButton";
            this.IDButton.Size = new System.Drawing.Size(66, 38);
            this.IDButton.TabIndex = 18;
            this.IDButton.TabStop = true;
            this.IDButton.Text = "ID";
            this.IDButton.UseVisualStyleBackColor = true;
            // 
            // SchoolIDButton
            // 
            this.SchoolIDButton.AutoSize = true;
            this.SchoolIDButton.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.SchoolIDButton.Location = new System.Drawing.Point(100, 15);
            this.SchoolIDButton.Name = "SchoolIDButton";
            this.SchoolIDButton.Size = new System.Drawing.Size(172, 38);
            this.SchoolIDButton.TabIndex = 19;
            this.SchoolIDButton.TabStop = true;
            this.SchoolIDButton.Text = "学籍番号";
            this.SchoolIDButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SchoolIDButton);
            this.groupBox1.Controls.Add(this.IDButton);
            this.groupBox1.Location = new System.Drawing.Point(77, 157);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(283, 59);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HcsSportView);
            this.Controls.Add(this.NumberBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.label3);
            this.Name = "Search";
            this.Text = "Search_Scene";
            ((System.ComponentModel.ISupportInitialize)(this.HcsSportView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox NumberBox;
        private System.Windows.Forms.DataGridView HcsSportView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.RadioButton IDButton;
        private System.Windows.Forms.RadioButton SchoolIDButton;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}