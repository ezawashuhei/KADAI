﻿namespace SportHCS
{
    partial class ChangeScene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DataGridView = new System.Windows.Forms.DataGridView();
            this.CheckButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.ChangeButton = new System.Windows.Forms.Button();
            this.IDBox = new System.Windows.Forms.TextBox();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.CallNumberBox = new System.Windows.Forms.TextBox();
            this.SchoolIDBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.HomeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // DataGridView
            // 
            this.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView.Location = new System.Drawing.Point(335, 158);
            this.DataGridView.Name = "DataGridView";
            this.DataGridView.RowHeadersWidth = 51;
            this.DataGridView.RowTemplate.Height = 24;
            this.DataGridView.Size = new System.Drawing.Size(441, 215);
            this.DataGridView.TabIndex = 2;
            // 
            // CheckButton
            // 
            this.CheckButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.CheckButton.ForeColor = System.Drawing.Color.Blue;
            this.CheckButton.Location = new System.Drawing.Point(31, 36);
            this.CheckButton.Name = "CheckButton";
            this.CheckButton.Size = new System.Drawing.Size(103, 55);
            this.CheckButton.TabIndex = 3;
            this.CheckButton.Text = "確認";
            this.CheckButton.UseVisualStyleBackColor = true;
            this.CheckButton.Click += new System.EventHandler(this.VerificationButtonClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(308, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 34);
            this.label3.TabIndex = 7;
            this.label3.Text = "変更画面";
            // 
            // ChangeButton
            // 
            this.ChangeButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.ChangeButton.ForeColor = System.Drawing.Color.Blue;
            this.ChangeButton.Location = new System.Drawing.Point(599, 36);
            this.ChangeButton.Name = "ChangeButton";
            this.ChangeButton.Size = new System.Drawing.Size(177, 57);
            this.ChangeButton.TabIndex = 8;
            this.ChangeButton.Text = "更新";
            this.ChangeButton.UseVisualStyleBackColor = true;
            this.ChangeButton.Click += new System.EventHandler(this.ChangeButtonClick);
            // 
            // IDBox
            // 
            this.IDBox.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.IDBox.Location = new System.Drawing.Point(42, 158);
            this.IDBox.Name = "IDBox";
            this.IDBox.Size = new System.Drawing.Size(273, 32);
            this.IDBox.TabIndex = 9;
            this.IDBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberBoxKeyPress);
            // 
            // NameBox
            // 
            this.NameBox.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.NameBox.Location = new System.Drawing.Point(42, 219);
            this.NameBox.Name = "NameBox";
            this.NameBox.Size = new System.Drawing.Size(273, 32);
            this.NameBox.TabIndex = 10;
            // 
            // CallNumberBox
            // 
            this.CallNumberBox.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.CallNumberBox.Location = new System.Drawing.Point(42, 281);
            this.CallNumberBox.Name = "CallNumberBox";
            this.CallNumberBox.Size = new System.Drawing.Size(273, 32);
            this.CallNumberBox.TabIndex = 11;
            this.CallNumberBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberBoxKeyPress);
            // 
            // SchoolIDBox
            // 
            this.SchoolIDBox.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.SchoolIDBox.Location = new System.Drawing.Point(42, 341);
            this.SchoolIDBox.Name = "SchoolIDBox";
            this.SchoolIDBox.Size = new System.Drawing.Size(273, 32);
            this.SchoolIDBox.TabIndex = 12;
            this.SchoolIDBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberBoxKeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label1.Location = new System.Drawing.Point(37, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label2.Location = new System.Drawing.Point(37, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 25);
            this.label2.TabIndex = 14;
            this.label2.Text = "NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label4.Location = new System.Drawing.Point(37, 253);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "CallNunmeber";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label5.Location = new System.Drawing.Point(37, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 25);
            this.label5.TabIndex = 16;
            this.label5.Text = "SCHOOL/ID";
            // 
            // HomeButton
            // 
            this.HomeButton.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.HomeButton.ForeColor = System.Drawing.Color.Blue;
            this.HomeButton.Location = new System.Drawing.Point(636, 399);
            this.HomeButton.Name = "HomeButton";
            this.HomeButton.Size = new System.Drawing.Size(140, 39);
            this.HomeButton.TabIndex = 17;
            this.HomeButton.Text = "メニューへ";
            this.HomeButton.UseVisualStyleBackColor = true;
            this.HomeButton.Click += new System.EventHandler(this.HomeButtonClick);
            // 
            // ChangeScene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.HomeButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SchoolIDBox);
            this.Controls.Add(this.CallNumberBox);
            this.Controls.Add(this.NameBox);
            this.Controls.Add(this.IDBox);
            this.Controls.Add(this.ChangeButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CheckButton);
            this.Controls.Add(this.DataGridView);
            this.Name = "ChangeScene";
            this.Text = "Change_Scene";
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DataGridView;
        private System.Windows.Forms.Button CheckButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ChangeButton;
        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.TextBox CallNumberBox;
        private System.Windows.Forms.TextBox SchoolIDBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button HomeButton;
    }
}