﻿using System;
using System.Windows.Forms;
using System.Data.SQLite;

namespace SportHCS
{
    public partial class HomeMenu : Form //Home
    {
        public HomeMenu()
        {
            InitializeComponent();
        }

        private void SingupButtonClick(object sender, EventArgs e)　//新規登録へ
        {
            //次画面を非表示   
            this.Visible = false;

            SignUpScene SingUpScene = new SignUpScene();
            SingUpScene.Show();

        }

        private void ChangeButtonClick(object sender, EventArgs e) //変更画面へ
        {
            //次画面を非表示
            this.Visible = false;

            ChangeScene form4 = new ChangeScene();
            form4.Show();

        }

       

        private void DeleteButtonClick(object sender, EventArgs e) //削除画面へ
        {
            //次画面を非表示
            this.Visible = false;

            DeleteScene form6 = new DeleteScene();
            form6.Show();
        }

        private void SearchButtonClick(object sender, EventArgs e) //検索画面へ
        {
            //次画面を非表示
            this.Visible = false;

            Search Search = new Search();
            Search.Show();

        }

        private void DateMakeingButtonClick(object sender, EventArgs e)　//ボタン押したらデータベース作成される
        {
            // コネクションを開いてテーブル作成して閉じる  
            using (var con = new SQLiteConnection("Data Source=table.db"))
            {
                con.Open();
                using (SQLiteCommand command = con.CreateCommand())
                {
                    command.CommandText =
                        "create table t_product(ID INTEGER  PRIMARY KEY AUTOINCREMENT, name TEXT, callNumber TEXT, schoolID INTEGER)";
                    command.ExecuteNonQuery();
                }
                con.Close();
            }
        }
    }
}
