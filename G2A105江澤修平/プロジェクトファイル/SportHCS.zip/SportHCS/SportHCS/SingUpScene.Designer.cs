﻿
namespace SportHCS
{
    partial class SignUpScene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberBox = new System.Windows.Forms.TextBox();
            this.CallNumber = new System.Windows.Forms.TextBox();
            this.SchoolID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CompletionButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NumberBox
            // 
            this.NumberBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NumberBox.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.NumberBox.Location = new System.Drawing.Point(120, 168);
            this.NumberBox.Name = "NumberBox";
            this.NumberBox.Size = new System.Drawing.Size(524, 41);
            this.NumberBox.TabIndex = 0;
            // 
            // CallNumber
            // 
            this.CallNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CallNumber.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.CallNumber.Location = new System.Drawing.Point(120, 264);
            this.CallNumber.Name = "CallNumber";
            this.CallNumber.Size = new System.Drawing.Size(524, 41);
            this.CallNumber.TabIndex = 1;
            this.CallNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberTextKeyPress);
            // 
            // SchoolID
            // 
            this.SchoolID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SchoolID.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.SchoolID.Location = new System.Drawing.Point(117, 359);
            this.SchoolID.Name = "SchoolID";
            this.SchoolID.Size = new System.Drawing.Size(521, 41);
            this.SchoolID.TabIndex = 2;
            this.SchoolID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberTextKeyPress);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(111, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 34);
            this.label2.TabIndex = 4;
            this.label2.Text = "氏名";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(114, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 34);
            this.label3.TabIndex = 5;
            this.label3.Text = "電話番号";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(114, 322);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 34);
            this.label4.TabIndex = 6;
            this.label4.Text = "学籍番号";
            // 
            // CompletionButton
            // 
            this.CompletionButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CompletionButton.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CompletionButton.ForeColor = System.Drawing.Color.Blue;
            this.CompletionButton.Location = new System.Drawing.Point(641, 27);
            this.CompletionButton.Name = "CompletionButton";
            this.CompletionButton.Size = new System.Drawing.Size(159, 43);
            this.CompletionButton.TabIndex = 7;
            this.CompletionButton.Text = "記入完了";
            this.CompletionButton.UseVisualStyleBackColor = false;
            this.CompletionButton.Click += new System.EventHandler(this.CompletionButtonClick);
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackButton.BackColor = System.Drawing.Color.Tomato;
            this.BackButton.ForeColor = System.Drawing.Color.Blue;
            this.BackButton.Location = new System.Drawing.Point(12, 27);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(159, 43);
            this.BackButton.TabIndex = 8;
            this.BackButton.Text = "戻る";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButtonClick);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightBlue;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(331, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 34);
            this.label1.TabIndex = 9;
            this.label1.Text = "入力欄";
            // 
            // SignUpScene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(812, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.CompletionButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SchoolID);
            this.Controls.Add(this.CallNumber);
            this.Controls.Add(this.NumberBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "SignUpScene";
            this.Text = "新規登録";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NumberBox;
        private System.Windows.Forms.TextBox CallNumber;
        private System.Windows.Forms.TextBox SchoolID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button CompletionButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
    }
}