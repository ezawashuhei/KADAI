﻿using System;
using System.Windows.Forms;
using System.Data.SQLite;
namespace SportHCS
{
    //新規登録 SingUpScene
    public partial class SignUpScene : Form 
    {
        public SignUpScene()
        {
            InitializeComponent();
        }

        /// <summary>
        /// テキストボックス内に中身が入っているか確認し、
        /// 入ってなければエラーメッセージ表示する。
        /// 入っていればt_productに新規でデータを登録する。
        /// </summary>
        private void CompletionButtonClick(object sender, EventArgs e)//完了ボタン
        {
            //もしテキストに何も書いてなかったら
            if (NumberBox.Text == "" || CallNumber.Text == "" || SchoolID.Text == "") 
            {
                MessageBox.Show("正しい値を入力してください。", "エラー",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
            else　//テキストに文字が記入されていたら
            {
                using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))　//データベースに追加
                {
                    con.Open();
                    using (SQLiteTransaction trans = con.BeginTransaction())
                    {
                        SQLiteCommand cmd = con.CreateCommand();
                        // インサート
                        cmd.CommandText = "INSERT INTO t_product (name, callNumber, schoolID) VALUES (@Name, @CallNumber, @SchoolID)";
                        // パラメータセット
                        cmd.Parameters.Add("Name", System.Data.DbType.String);
                        cmd.Parameters.Add("CallNumber", System.Data.DbType.String);
                        cmd.Parameters.Add("SchoolID", System.Data.DbType.String);
                        // データ追加
                        cmd.Parameters["Name"].Value = NumberBox.Text;
                        cmd.Parameters["CallNumber"].Value = CallNumber.Text;
                        cmd.Parameters["SchoolID"].Value = SchoolID.Text;
                        cmd.ExecuteNonQuery();
                        // コミット
                        trans.Commit();
                    }
                }

                //次画面を非表示
                this.Visible = false;
                //確認画面へ
                Check CheckScene = new Check();
                CheckScene.Show();
            }

        }

        /// <summary>
        /// ホーム画面に戻る。
        /// </summary>
        private void BackButtonClick(object sender, EventArgs e)//戻るボタン
        {
            //次画面を非表示
            this.Visible = false;
            //ホーム画面へ
            HomeMenu home = new HomeMenu();
            home.Show();
        }

        /// <summary>
        /// 英数字のみしか記入できないように設定。
        /// </summary>
        private void NumberTextKeyPress(object sender, KeyPressEventArgs Number)//英数字のみ記入可能
        {
            //バックスペースが押されたときは有効
            if (Number.KeyChar == '\b')
            {
                return;
            }
            
            //数値0～9以外を押されたときはイベントキャンセル
            if (Number.KeyChar < '0' || '9' < Number.KeyChar)
            {
                Number.Handled = true;
            }
        }
    }
}
