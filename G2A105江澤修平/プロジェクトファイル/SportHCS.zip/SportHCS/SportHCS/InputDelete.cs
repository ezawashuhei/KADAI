﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;

namespace SportHCS
{
    //データ削除フォーム
    public partial class InputDelete : Form
    {
        public InputDelete()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 入力されたIDと該当したデータを削除する。
        /// </summary>
        private void DeleteButtonClick(object sender, EventArgs e)
        {
            using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))
            {
                con.Open();
                using (SQLiteTransaction trans = con.BeginTransaction())
                {
                    SQLiteCommand cmd = con.CreateCommand();
                    // インサート
                    cmd.CommandText = "DELETE FROM t_product WHERE ID = @Id;";
                    // パラメータセット
                    cmd.Parameters.Add("Id", System.Data.DbType.Int64);
                    // データ削除
                    cmd.Parameters["Id"].Value = int.Parse(IDBox.Text);
                    cmd.ExecuteNonQuery();
                    // コミット
                    trans.Commit();
                }
            }

            using (SQLiteConnection con = new SQLiteConnection("Data Source=table.db"))
            {
                // DataTableを生成します。
                var dataTable = new DataTable();
                // SQLの実行
                var adapter = new SQLiteDataAdapter("SELECT * FROM t_product", con);
                adapter.Fill(dataTable);
                DataGridView.DataSource = dataTable;
            }
        }

        /// <summary>
        /// ホーム画面に変更
        /// </summary>
        private void HomeButtonClick(object sender, EventArgs e)
        {
            //次画面を非表示
            this.Visible = false;

            HomeMenu home = new HomeMenu();
            home.Show();
        }

        /// <summary>
        /// 英数字しか記入出来ないように設定。
        /// </summary>
        private void IDTextKeyPress(object sender, KeyPressEventArgs Number)//英数字のみ記入可能
        {
            //バックスペースが推されたときは有効
            if(Number.KeyChar == '\b')
            {
                return;
            }

            //数値0～9以外を押されたときはイベントキャンセル
            if(Number.KeyChar < '0'||'9'< Number.KeyChar)
            {
                Number.Handled = true;
            }
        }
    }
}
