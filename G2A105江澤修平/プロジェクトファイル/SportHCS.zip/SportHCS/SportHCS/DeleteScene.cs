﻿using System;
using System.Windows.Forms;
using System.Data.SQLite;

namespace SportHCS
{
    public partial class DeleteScene : Form
    {
        public DeleteScene()
        {
            InitializeComponent();
        }

        private void TableDeleteButtonClick(object sender, EventArgs e)
        {
            // コネクションを開いてテーブル削除して閉じる  
            using (var con = new SQLiteConnection("Data Source=table.db"))
            {
                con.Open();
                using (SQLiteCommand command = con.CreateCommand())
                {
                    command.CommandText =
                        "drop table t_product";
                    command.ExecuteNonQuery();
                }
                con.Close();
            }
        }

        /// <summary>
        /// 画面遷移・入力削除へ
        /// </summary>
        private void InputDeleteButtonClick(object sender, EventArgs e)
        {
            //次画面を非表示
            this.Visible = false;

            InputDelete InputDelete = new InputDelete();
            InputDelete.Show();
        }

        /// <summary>
        /// 画面繊維・ホームへ
        /// </summary>
        private void HomeButtonClick(object sender, EventArgs e)
        {
            //次画面を非表示
            this.Visible = false;

            HomeMenu form1 = new HomeMenu();
            form1.Show();
        }
    }
}
